const mongoose = require('mongoose');

const LeaveSchema = new mongoose.Schema({
    employee: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' },
    leaveType: { type: String, enum: ['Annual', 'Sick', 'Unpaid'] },
    startDate: Date,
    endDate: Date,
    status: { type: String, enum: ['Pending', 'Approved', 'Rejected'] }
});

module.exports = mongoose.model('Leave', LeaveSchema);