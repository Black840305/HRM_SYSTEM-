const Notification = require("../models/notificationModel");

exports.getAllNotifications = async (req, res) => {
  try {
    const notifications = await Notification.find().populate("recipients");
    res.json(notifications);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};

exports.getNotificationById = async (req, res) => {
  try {
    const notification = await Notification.findById(req.params.id).populate(
      "recipients"
    );
    if (!notification)
      return res.status(404).json({ msg: "Notification not found" });
    res.json(notification);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};

exports.createNotification = async (req, res) => {
  const { title, message, recipients } = req.body;

  try {
    const newNotification = new Notification({ title, message, recipients });
    await newNotification.save();
    res.status(201).json(newNotification);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};

exports.updateNotification = async (req, res) => {
  const { title, message, recipients } = req.body;

  try {
    const notification = await Notification.findById(req.params.id);
    if (!notification)
      return res.status(404).json({ msg: "Notification not found" });

    notification.title = title || notification.title;
    notification.message = message || notification.message;
    notification.recipients = recipients || notification.recipients;

    await notification.save();
    res.json(notification);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};

exports.deleteNotification = async (req, res) => {
  try {
    const notification = await Notification.findById(req.params.id);
    if (!notification)
      return res.status(404).json({ msg: "Notification not found" });

    await notification.remove();
    res.json({ msg: "Notification removed" });
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};
