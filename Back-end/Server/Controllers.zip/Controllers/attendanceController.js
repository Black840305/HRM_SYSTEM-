const Attendance = require("../models/attendanceModel");

exports.getAllAttendances = async (req, res) => {
  try {
    const attendances = await Attendance.find().populate("employee");
    res.json(attendances);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};

exports.getAttendanceById = async (req, res) => {
  try {
    const attendance = await Attendance.findById(req.params.id).populate(
      "employee"
    );
    if (!attendance)
      return res.status(404).json({ msg: "Attendance not found" });
    res.json(attendance);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};

exports.createAttendance = async (req, res) => {
  const { employee, date, status } = req.body;

  try {
    const newAttendance = new Attendance({ employee, date, status });
    await newAttendance.save();
    res.status(201).json(newAttendance);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};

exports.updateAttendance = async (req, res) => {
  const { date, status } = req.body;

  try {
    const attendance = await Attendance.findById(req.params.id);
    if (!attendance)
      return res.status(404).json({ msg: "Attendance not found" });

    attendance.date = date || attendance.date;
    attendance.status = status || attendance.status;

    await attendance.save();
    res.json(attendance);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};

exports.deleteAttendance = async (req, res) => {
  try {
    const attendance = await Attendance.findById(req.params.id);
    if (!attendance)
      return res.status(404).json({ msg: "Attendance not found" });

    await attendance.remove();
    res.json({ msg: "Attendance removed" });
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};
