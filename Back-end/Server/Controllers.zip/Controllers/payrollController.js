const Payroll = require("../models/payrollModel");

exports.getAllPayrolls = async (req, res) => {
  try {
    const payrolls = await Payroll.find().populate("employee", );
    res.json(payrolls);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};

exports.getPayrollById = async (req, res) => {
  try {
    const payroll = await Payroll.findById(req.params.id).populate("employee");
    if (!payroll) return res.status(404).json({ msg: "Payroll not found" });
    res.json(payroll);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};

exports.createPayroll = async (req, res) => {
  const { employee, baseSalary, allowances, bonuses, deductions } = req.body;

  try {
    const newPayroll = new Payroll({
      employee,
      baseSalary,
      allowances,
      bonuses,
      deductions,
    });
    await newPayroll.save();
    res.status(201).json(newPayroll);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};

exports.updatePayroll = async (req, res) => {
  const { baseSalary, allowances, bonuses, deductions } = req.body;

  try {
    const payroll = await Payroll.findById(req.params.id);
    if (!payroll) return res.status(404).json({ msg: "Payroll not found" });

    payroll.baseSalary = baseSalary || payroll.baseSalary;
    payroll.allowances = allowances || payroll.allowances;
    payroll.bonuses = bonuses || payroll.bonuses;
    payroll.deductions = deductions || payroll.deductions;

    await payroll.save();
    res.json(payroll);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};

exports.deletePayroll = async (req, res) => {
  try {
    const payroll = await Payroll.findById(req.params.id);
    if (!payroll) return res.status(404).json({ msg: "Payroll not found" });

    await payroll.remove();
    res.json({ msg: "Payroll removed" });
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};
