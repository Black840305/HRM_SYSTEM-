const Employee = require("../models/employeeModel");
const User = require("../models/userModel");
const bcrypt = require("bcryptjs");
const Payroll = require("../models/payrollModel");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

// Controller lấy tất cả nhân viên
const getAllEmployees = async (req, res) => {
  try {
    const employees = await Employee.find()
      .populate("user", "email role")
      .populate("department", "name")
      .populate("salary", "baseSalary");

    // Xử lý trả về kết quả với kiểm tra null/undefined
    const result = employees.map((employee) => ({
      _id: employee._id,
      name: employee.name || "Chưa cập nhật",
      email: employee.user?.email || "Chưa cập nhật",
      dob: employee.dob
        ? employee.dob instanceof Date
          ? employee.dob.toISOString().split("T")[0]
          : "Chưa cập nhật"
        : "Chưa cập nhật",
      gender: employee.gender || "Chưa cập nhật",
      address: employee.address || "Chưa cập nhật",
      phone: employee.phone || "Chưa cập nhật",
      department: employee.department?.name || "Chưa cập nhật",
      position: employee.position || "Chưa cập nhật",
      salary: employee.salary?.baseSalary || 0,
      startDate: employee.startDate
        ? employee.startDate instanceof Date
          ? employee.startDate.toISOString().split("T")[0]
          : "Chưa cập nhật"
        : "Chưa cập nhật",
      avatar: employee.avatar || "",
      role: employee.user?.role || "employee",
    }));

    return res.json(result);
  } catch (err) {
    console.error("Error fetching employees:", err);
    return res.status(500).json({
      message: "Lỗi khi lấy danh sách nhân viên",
      error: err.message,
    });
  }
};

// Controller lấy thông tin nhân viên theo ID
const getEmployeeById = async (req, res) => {
  try {
    console.log(`Đang tìm nhân viên với ID: ${req.params.id}`);

    const employee = await Employee.findById(req.params.id)
      .populate("department", "name")
      .populate("user", "username email role")
      .populate("salary", "baseSalary");

    if (!employee) {
      console.log(`Không tìm thấy nhân viên với ID ${req.params.id}`);
      return res.status(404).json({ message: "Không tìm thấy nhân viên" });
    }

    // Kiểm tra quyền truy cập
    if (
      req.user.role !== "admin" &&
      (!req.user.employeeId ||
        req.user.employeeId.toString() !== employee._id.toString())
    ) {
      console.log(
        `Từ chối truy cập - user ${req.user.id} cố gắng xem thông tin nhân viên ${employee._id}`
      );
      return res
        .status(403)
        .json({ message: "Bạn không có quyền truy cập thông tin này" });
    }

    // Định dạng kết quả với kiểm tra null/undefined
    const result = {
      _id: employee._id,
      name: employee.name || "Chưa cập nhật",
      email: employee.user?.email || "Chưa cập nhật",
      dob: employee.dob
        ? employee.dob instanceof Date
          ? employee.dob.toISOString().split("T")[0]
          : "Chưa cập nhật"
        : "Chưa cập nhật",
      gender: employee.gender || "Chưa cập nhật",
      address: employee.address || "Chưa cập nhật",
      phone: employee.phone || "Chưa cập nhật",
      department: employee.department?.name || "Chưa cập nhật",
      position: employee.position || "Chưa cập nhật",
      salary: employee.salary?.baseSalary || 0,
      startDate: employee.startDate
        ? employee.startDate instanceof Date
          ? employee.startDate.toISOString().split("T")[0]
          : "Chưa cập nhật"
        : "Chưa cập nhật",
      avatar: employee.avatar || "",
      role: employee.user?.role || "employee",
    };

    return res.json(result);
  } catch (error) {
    console.error(`Lỗi trong getEmployeeById: ${error.message}`);
    return res
      .status(500)
      .json({ message: "Lỗi server", error: error.message });
  }
};

const createEmployee = async (req, res) => {
  const {
    username,
    email,
    password,
    name,
    dob,
    gender,
    address,
    phone,
    departmentId,
    position,
    salary,
    startDate,
    avatar,
  } = req.body;

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      username,
      email,
      password: hashedPassword,
      role: "Employee",
    });

    await newUser.save();

    const newEmployee = new Employee({
      user: newUser._id,
      name,
      dob,
      gender,
      address,
      phone,
      department: departmentId,
      position,
      salary,
      startDate,
      avatar,
    });

    await newEmployee.save();

    newUser.employeeId = newEmployee._id;
    await newUser.save();

    res.status(201).json(newEmployee);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
};

const updateEmployee = async (req, res) => {
  const {
    name,
    dob,
    gender,
    address,
    phone,
    department,
    position,
    salary,
    startDate,
  } = req.body;

  try {
    const employee = await Employee.findById(req.params.id);
    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    employee.name = name ?? employee.name;
    employee.dob = dob ?? employee.dob;
    employee.gender = gender ?? employee.gender;
    employee.address = address ?? employee.address;
    employee.phone = phone ?? employee.phone;
    employee.department = department ?? employee.department;
    employee.position = position ?? employee.position;
    employee.startDate = startDate ?? employee.startDate;
    // employee.salary = salary ?? employee.salary;
    const updatedEmployee = await employee.save();
    await updatedEmployee.populate("department", "name");
    // .populate("salary", "baseSalary");
    res.json(updatedEmployee);
  } catch (err) {
    console.error("Error updating employee:", err);
    if (err.name === "ValidationError") {
      return res.status(400).json({ message: err.message });
    } else {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
};

const deleteEmployee = async (req, res) => {
  try {
    // Tìm nhân viên theo ID
    const employee = await Employee.findById(req.params.id);
    if (!employee) {
      return res.status(404).json({ message: "Không tìm thấy nhân viên" });
    }

    // Xóa avatar nếu có
    if (employee.avatar) {
      const fs = require("fs");
      const path = require("path");
      const avatarPath = path.join(__dirname, "..", "..", employee.avatar);

      // Kiểm tra file tồn tại trước khi xóa
      if (fs.existsSync(avatarPath)) {
        fs.unlinkSync(avatarPath);
      }
    }

    // Xóa bản ghi liên quan từ bảng User
    if (employee.user) {
      await User.findByIdAndDelete(employee.user);
    }

    // Xóa bản ghi liên quan từ bảng Payroll
    await Payroll.deleteMany({ employee: employee._id });

    // Xóa nhân viên
    await Employee.findByIdAndDelete(req.params.id);

    res.json({ message: "Đã xóa nhân viên thành công" });
  } catch (err) {
    console.error("Error deleting employee:", err);
    res.status(500).json({ message: "Lỗi máy chủ", error: err.message });
  }
};

const getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).lean(); // ✅ Trả về object JSON thuần

    if (!user) {
      return res.status(404).json({ message: "User không tồn tại" });
    }

    // ✅ Kiểm tra Employee
    const employee = await Employee.findOne({ user: user._id })
      .select("_id")
      .lean();

    res.json({
      id: user._id.toString(),
      username: user.username,
      email: user.email,
      role: user.role,
      employeeId: employee ? employee._id.toString() : null, // ✅ Chỉ trả về ID dạng string
    });
  } catch (error) {
    console.error("Lỗi lấy thông tin user:", error);

    res.status(500).json({ message: "Lỗi server" });
  }
};

// Configure multer storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = "uploads/avatars";
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    cb(null, "avatar-" + uniqueSuffix + ext);
  },
});

// File filter to accept only images
const fileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("image/")) {
    cb(null, true);
  } else {
    cb(new Error("Only image files are allowed!"), false);
  }
};

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB max file size
  },
  fileFilter: fileFilter,
});

// Upload avatar endpoint
const uploadAvatar = async (req, res) => {
  try {
    // Use multer middleware for single file upload
    upload.single("avatar")(req, res, async function (err) {
      if (err) {
        return res.status(400).json({ message: err.message });
      }

      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const employeeId = req.params.id;

      // Find employee and update avatar field
      const employee = await Employee.findById(employeeId);

      if (!employee) {
        // Remove uploaded file if employee not found
        fs.unlinkSync(req.file.path);
        return res.status(404).json({ message: "Employee not found" });
      }

      // Delete old avatar file if exists
      if (employee.avatar && fs.existsSync(employee.avatar)) {
        fs.unlinkSync(employee.avatar);
      }

      // Update employee with new avatar path
      employee.avatar = req.file.path;
      await employee.save();

      res.status(200).json({
        message: "Avatar uploaded successfully",
        avatarUrl: `http://localhost:3000/${req.file.path.replace(/\\/g, "/")}`,
      });
    });
  } catch (error) {
    console.error("Error uploading avatar:", error);
    res.status(500).json({ message: "Error uploading avatar" });
  }
};
module.exports = {
  getAllEmployees,
  getEmployeeById,
  createEmployee,
  updateEmployee,
  deleteEmployee,
  getMe,
  uploadAvatar,
};
